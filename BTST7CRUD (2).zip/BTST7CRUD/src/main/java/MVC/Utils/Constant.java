package MVC.Utils;

public class Constant {
	public static final String DIR = "D:\\upload";
	public static final String SESSION_USERNAME = "username";
	public static final String COOKIE_REMEMBER = "username";
	public static final String REGISTER = "/views/web/register.jsp";
	public static final String LOGIN = "/views/web/login.jsp";
	public static final String Path = null;
}
